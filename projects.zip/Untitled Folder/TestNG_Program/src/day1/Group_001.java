package day1;

import org.testng.annotations.Test;

public class Group_001 
{
	
	
	@Test(groups= {"SmokeTest"})
	public void WebLogin()
	{
		
		System.out.println("Weblogin details");
	}
	
	
	@Test(groups= {"SmokeTest"})
	public void MobileLogin()
	{
		System.out.println("Mobile Details");
	}
	
	@Test
	public void ApiLogin()
	{
		System.out.println("API Login Details");
		
	}

}
