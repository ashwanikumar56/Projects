package day1;

import org.testng.annotations.Test;

public class Home_loan 
{
	
	@Test  
	public void home_loan()  
	{  
	  System.out.println("Home Loan");  
	}  


}
