package day1;

import org.testng.annotations.Test;

public class Test_002 
{
	
	@Test
	public void WebLogin()
	{
		System.out.println("Hello Web");
	}
	
	@Test
	public  void MobileLoan()
	{
		System.out.println("Hello mobile");
		
	}
	
	@Test
	public void ApiLogin()
	{
		System.out.println("Hello ApiLogin");
		
	}

}
