package day1;

import org.testng.annotations.Test;

public class Group_002
{
	
	@Test
	public void HomeLoan()
	{
		System.out.println("HomeLoan");
	}
	
	@Test(groups= {"SmokeTest"})
	public void MobileLoan()
	{
		System.out.println("Mobile Loan");
	}
	
	@Test(groups= {"SmokeTest"}) 
	public void ApiLoan()
	{
		System.out.println("ApiLoan");
	}

}
