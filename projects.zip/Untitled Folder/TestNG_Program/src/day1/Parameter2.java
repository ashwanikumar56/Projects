package day1;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Parameter2 
{
	
	@Test 
	@Parameters("mango")  
	public void mango(String m)  
	{  
	System.out.println("Fruits names are:  ");  
	System.out.println(m);  
	}  

}
