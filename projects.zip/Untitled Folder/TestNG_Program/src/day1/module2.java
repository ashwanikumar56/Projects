package day1;

	import org.testng.annotations.Test;  
	  
	public class module2   
	{  
	    @Test  
	  public void test3()  
	  {  
	      System.out.println("hindi100.com");  
	  }  
	}  


