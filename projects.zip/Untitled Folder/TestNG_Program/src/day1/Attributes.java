package day1;

import org.testng.annotations.Test;

public class Attributes
{
	
    
	@Test(description="This is testcase1")  
	public void testcase1()  
	{  
		System.out.println("HR");  
	}  
	
	
	@Test(description="This is testcase2")  
	public void testcase2()  
	{  
		System.out.println("Software Developer");  
	}  
	
	@Test  
	public void WebStudentLogin()  
	{  
	System.out.println("Student login through web");  
	}  
	
	@Test(dependsOnMethods= {"WebStudentLogin"})  //WebStudentLogin is execute after the APIStudentsLogin Method
	public void APIStudentLogin()  
	{  
	System.out.println("Student login through API");  
	}  

}
