package day1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Hr_dep 
{
	
	  @AfterTest			  
	    public void manager()  
	    {  
	        System.out.println("Manager");  
	    }  
	      
	    @Test  
	      
	    public void hr()  
	    {  
	        System.out.println("HR");  
	    }  
	      
	    @Test  
	    public void counsellor()  
	    {  
	        System.out.println("Counsellor");  
	    }  

	   //@AfterTest is applied to the perticular folder 
}
