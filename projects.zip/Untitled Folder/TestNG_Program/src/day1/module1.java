package day1;

import org.testng.annotations.Test;

public class module1 
{
	
	 @Test  
	    public void test1()  
	    {  
	        System.out.println("Hello javaTpoint!!");  
	    }  
	      
	    @Test  
	    public void test2()  
	    {  
	        System.out.println("JTP Travels");  
	    }

}
