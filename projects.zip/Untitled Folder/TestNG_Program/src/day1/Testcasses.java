package day1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Testcasses
{
	
	@Test
	public void testtopass()  
	{  
	Assert.assertTrue(true);  
	}  
	
	
	@Test  
	public void testtofail()  
	{  
	Assert.assertFalse(false);  
	}  

}
