package day1;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class Car_loan 
{
	
	@AfterSuite
	public void car_loan()
	{
		System.out.println("Car_loan");
	}
	
	//run after call the test cases of all classes

}
