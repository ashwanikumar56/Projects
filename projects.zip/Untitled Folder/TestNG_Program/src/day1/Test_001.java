package day1;

import org.testng.annotations.Test;

public class Test_001 
{
	
	@Test
	public void test1()
	{
		System.out.println("hello Selenium");
	}
	
	@Test
	public void Test2()
	{
		System.out.println("Hello java");
	}

}
