package com.QA.TestNGDemo;

import org.testng.annotations.Test;

public class First 
{
	
	@Test
	public void test1()
	{
		System.out.println("test1");
		
	}
	
	@Test
	public void test2()
	{
		System.out.println("test2");
	}

}
