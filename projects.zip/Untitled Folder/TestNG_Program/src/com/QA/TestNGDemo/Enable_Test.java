package com.QA.TestNGDemo;

import org.testng.annotations.Test;

public class Enable_Test
{
	
	@Test(enabled = false)
	public void test1()
	{
		System.out.println("Hello");
	}
	
	@Test
	public void test2()
	{
		System.out.println("Hello2");
	}

}
