package com.QA.Assertion;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertion_001 
{
	
	@Test
	public void Test1()
	{
		System.setProperty("webdriver.chrome.driver", "/home/qainfotech/Downloads/chromedriver");
		WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("http://google.com");
		Assert.assertEquals("google", driver.getTitle());
		
		
	}
	
	@Test
	public void test2()
	{
		Assert.assertFalse(true);
	}
	
	@Test
	public void test3()
	{
		System.out.println("Hello");
	}
	
	

}
