package com.Annotation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;

public class annotation
{
	WebDriver driver=null;
	 @Given("^I am on web scraper login page$") 
	public void goToFacebook() {
		System.setProperty("webdriver.chrome.driver", "/home/qainfotech/Downloads/chromedriver");
		driver=new ChromeDriver();		
		driver.navigate().to("https://www.facebook.com/");
		
	}
	 
	 @When("^ I enter username as (.*)$")
	 public void enterusername(String args1) 
	 {
		 driver.findElement(By.id("usr")).sendKeys(args1);
		 
		 
	 }
	 
	 @When("^ I enter password as (.*)$")
	 public void enterpassword(String args1)
	 {
		 driver.findElement(By.id("pwd")).sendKeys(args1);
		 driver.findElement(By.xpath("//input[@value='Login']")).click();

	 }
	 
	 @Then("^Login shouold fail$")
	 public void CheckFail()
	 {
		
		 if(driver.getCurrentUrl().equalsIgnoreCase("http://testing-ground.scraping.pro/login?mode=login"))
		 {
			 System.out.println("Test1 Pass");
		 }
		 else
		 {
			 System.out.println("Test Failed");
		 }
	 }
	 
	 
	 
	
}