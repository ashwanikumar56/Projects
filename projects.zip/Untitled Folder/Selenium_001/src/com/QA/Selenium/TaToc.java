package com.QA.Selenium;

import java.util.NoSuchElementException;

import javax.lang.model.element.Element;
import java.util.*;
import java.io.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TaToc {
	int c=1;
	static String  main="";
	static String child="";

	public static void main(String[] args) 
	{
		
		
		System.setProperty("webdriver.chrome.driver","/home/qainfotech/Downloads/chromedriver");
		WebDriver driver=new ChromeDriver();
		
		
		driver.navigate().to("http://10.0.1.86/");
	
		
			driver.findElement(By.linkText("/tatoc")).click();
	
			driver.findElement(By.linkText("Basic Course")).click();
			
			driver.findElement(By.className("greenbox")).click();
			SwitchMain(driver);
			DragNDrop(driver);
			
			PopUp(driver);
			
			driver.findElement(By.linkText("Proceed")).click();
			driver.findElement(By.linkText("Generate Token")).click();
			
		
			String Token = driver.findElement(By.xpath("//span[@id = 'token']")).getText();
			System.out.println(Token);
			
			Token=Token.substring(7);	
					
			System.out.println(Token);
			
			
			AddCookies(driver,Token);
			
		
			
			driver.findElement(By.linkText("Proceed")).click();
					
			
	
	}
	
	public static void SwitchMain(WebDriver d)
	{
		d.switchTo().frame("main");
		main=d.findElement(By.id("answer")).getAttribute("class");
		System.out.println(main);
		d.switchTo().defaultContent();
		SwitchChild(d);
		
		
	
		
		
	}
	public static void SwitchChild(WebDriver d)
	{
		d.switchTo().frame("main");
		d.switchTo().frame("child");
		child=d.findElement(By.id("answer")).getAttribute("class");
		System.out.println(child);
		
		if(child.equals(main))
		{
			d.switchTo().defaultContent();
			d.switchTo().frame("main");
			d.findElement(By.linkText("Proceed")).click();
			d.switchTo().defaultContent();
			
		}
		else
		{
			d.switchTo().defaultContent();
			d.switchTo().frame("main");
			d.findElement(By.linkText("Repaint Box 2")).click();
			d.switchTo().defaultContent();
			SwitchChild(d);
			
		}
		
	}
	
	public static void DragNDrop(WebDriver d)
	{
		WebElement from=d.findElement(By.id("dragbox"));
		WebElement to=d.findElement(By.id("dropbox"));
		Actions act=new Actions(d); 
         
	       
	    act.dragAndDrop(from,to).build().perform();   
	    
	    d.findElement(By.linkText("Proceed")).click();
	    d.switchTo().defaultContent();
	            
	
	}
	
	public static void PopUp(WebDriver d)
	{
		d.findElement(By.linkText("Launch Popup Window")).click();
		
		  String MainWindow=d.getWindowHandle();		
  		
	        // To handle all new opened window.				
	            Set<String> s1=d.getWindowHandles();		
	        Iterator<String> i1=s1.iterator();		
	        
	        while(i1.hasNext())			
	        {		
	            String ChildWindow=i1.next();		
	            		
	            if(!MainWindow.equalsIgnoreCase(ChildWindow))			
	            {    		
	                 
	                    // Switching to Child window
	                    d.switchTo().window(ChildWindow);	                                                                                                           
	                    d.findElement(By.id("name"))
	                    .sendKeys("Hello133");                			
	                    
	                    d.findElement(By.id("submit")).click();			
	                                 
				// Closing the Child Window.
	                    //    d.close();		
	            }		
	        }
	        
	        d.switchTo().window(MainWindow);    		
		
	}
	
	public static void AddCookies(WebDriver d,String s)
	{	
		
		Cookie name = new Cookie("Token",s);
		d.manage().addCookie(name);
		
		
		
	}
	
}