package com.QA.Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Alert;
public class AlertDemo {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "/home/qainfotech/Downloads/chromedriver");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.testandquiz.com/selenium/testing.html");
		driver.findElement(By.linkText("Generate Alert Box")).click();
		
		
		
		Alert alert =(Alert)driver.switchTo().alert();
//		alert.accept();
//		
//		driver.findElement(By.linkText("Generate Confirm Box")).click();

	}

}
