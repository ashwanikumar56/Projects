package com.QA.Selenium;

import org.openqa.selenium.interactions.Actions;  

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Drag {

	public static void main(String[] args)
	{
		
		System.setProperty("webdriver.chrome.driver", "/home/qainfotech/Downloads/chromedriver");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.testandquiz.com/selenium/testing.html");
		
		WebElement from = driver.findElement(By.id("sourceImage"));  
		  
		
		WebElement to = driver.findElement(By.id("targetDiv"));
		
		Actions ac=new Actions(driver);
		
		System.out.println("print");
		
		ac.dragAndDrop(from, to).build().perform();
		
		
	}

}
