package com.QA.Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
public class Radio2 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","/home/qainfotech/Downloads/chromedriver");
		WebDriver driver=new ChromeDriver();
		
		
		driver.get("file:///home/qainfotech/Downloads/demo.html");
		
		  int a = driver.findElements(By.xpath("//input [@name='group1']")).size();  
		  
		  System.out.println(a);  
		  	
		   for(int i=1;i<=a;i++)  
	        {  
	            driver.findElements(By.xpath("//input[@name='group1']")).get(2).click();  
	        }  

	}

}
