package com.QA.Selenium;

public class Assertion_001 {

}
