package com.QA.Selenium;

import javax.management.RuntimeErrorException;

public class demo 
{
	
	public static void main(String[] args)
	{
		try
		{
			System.out.println("hhh");
			System.out.println("ggg");
			throw new RuntimeException();
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		
		System.out.println("jjjj");
	}

}
