package com.Keywords;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LaunchPopUp 
{
	

	WebDriver driver;
	Properties p;
	
	public LaunchPopUp(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void popup()
	{
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText(p.getProperty("launchpopup"))).click();
		
		  String MainWindow=driver.getWindowHandle();		
		
	        // To handle all new opened window.				
	            Set<String> s1=driver.getWindowHandles();		
	        Iterator<String> i1=s1.iterator();		
	        
	        while(i1.hasNext())			
	        {		
	            String ChildWindow=i1.next();		
	            		
	            if(!MainWindow.equalsIgnoreCase(ChildWindow))			
	            {    		
	                 
	                    // Switching to Child window
	                    driver.switchTo().window(ChildWindow);	                                                                                                           
	                    driver.findElement(By.id(p.getProperty("editTestid")))
	                    .sendKeys("Hello133");                			
	                    
	                    driver.findElement(By.id(p.getProperty("popupsubmitid"))).click();			
	                                 
				// Closing the Child Window.
	                    //    d.close();		
	            }		
	        }
	        
	        driver.switchTo().window(MainWindow);    
	}

}
