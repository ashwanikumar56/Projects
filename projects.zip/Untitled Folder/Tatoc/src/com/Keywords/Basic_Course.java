package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Basic_Course 
{
	
	WebDriver driver;
	Properties p;
	
	public Basic_Course(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void basicClick()
	{
		driver.findElement(By.linkText(p.getProperty("basic_course"))).click();
	}
	
	public String getTitle()
	{
		return driver.getTitle();
	}
	

}
