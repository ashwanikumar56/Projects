package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class ClickTatoc 
{
	WebDriver driver;
	Properties p;
	
	public ClickTatoc(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void clicktt()
	{
		
		driver.findElement(By.linkText(p.getProperty("tatocLink"))).click();
		
	}

	public String  getTatoc_title() {
		// TODO Auto-generated method stub
		String s=driver.getTitle();
		return s;
	}

}
