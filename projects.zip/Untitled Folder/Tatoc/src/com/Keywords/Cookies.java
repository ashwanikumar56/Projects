package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

public class Cookies 
{
	


	WebDriver driver;
	Properties p;
	
	public Cookies(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void Cookie(String tokenvalue)
	{

		Cookie name = new Cookie("Token",tokenvalue);
		driver.manage().addCookie(name);

		driver.findElement(By.linkText("Proceed")).click();
				
	}

}
