package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SwitchFrame 
{
	

	WebDriver driver;
	Properties p;
	static String  main="";
	static String child="";

	
	public SwitchFrame(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void framecheck()
	{
		driver.switchTo().frame(p.getProperty("MainFrame"));
		main=driver.findElement(By.id(p.getProperty("box1id"))).getAttribute("class");
		System.out.println(main);
		driver.switchTo().defaultContent();
		SwitchChild(driver);
	}
	
	public  void SwitchChild(WebDriver driver)
	{
		driver.switchTo().frame(p.getProperty("MainFrame"));
		driver.switchTo().frame(p.getProperty("ChildFrame"));
		child=driver.findElement(By.id(p.getProperty("box2id"))).getAttribute("class");
		System.out.println(child);
		
		if(child.equals(main))
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame(p.getProperty("MainFrame"));
			driver.findElement(By.linkText(p.getProperty("Proceed"))).click();
			driver.switchTo().defaultContent();
			
		}
		else
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame(p.getProperty("MainFrame"));
			driver.findElement(By.linkText(p.getProperty("reprint"))).click();
			driver.switchTo().defaultContent();
			SwitchChild(driver);
			
		}
	}

}
