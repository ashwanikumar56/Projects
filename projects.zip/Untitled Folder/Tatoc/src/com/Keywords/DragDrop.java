package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DragDrop 
{
	

	WebDriver driver;
	Properties p;
	
	public DragDrop(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void Drag()
	{
		WebElement from=driver.findElement(By.id(p.getProperty("Dragboxid")));
		WebElement to=driver.findElement(By.id(p.getProperty("Droptoid")));
		Actions act=new Actions(driver); 
         
	       
	    act.dragAndDrop(from,to).build().perform();   
	    
	    driver.findElement(By.linkText("Proceed")).click();
	    driver.switchTo().defaultContent();
	}

}
