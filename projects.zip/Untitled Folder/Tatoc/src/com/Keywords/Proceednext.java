package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Proceednext 
{
	

	WebDriver driver;
	Properties p;
	
	public Proceednext(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	
	public void Proceed()
	{
		driver.findElement(By.linkText(p.getProperty("Proceed"))).click();
		driver.findElement(By.linkText(p.getProperty("token"))).click();
	}

}
