package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Greenbox 
{
	
	WebDriver driver;
	Properties p;
	
	public Greenbox(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public void clickGreen()
	{
		driver.findElement(By.className(p.getProperty("Green"))).click();
	}
	

}
