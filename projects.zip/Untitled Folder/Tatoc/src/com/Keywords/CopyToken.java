package com.Keywords;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CopyToken 
{
	


	WebDriver driver;
	Properties p;
	
	public CopyToken(WebDriver driver,Properties p)
	{
		this.driver=driver;
		this.p=p;
		
	}
	
	public String Token()
	{
		String Token = driver.findElement(By.xpath(p.getProperty("spanid"))).getText();
		System.out.println(Token);
		
		Token=Token.substring(7);	
				
		
		return Token;
		
	}
	

}
