/**
 * 
 */
package com.Test;

import com.Keywords.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * This class is responsible to call action methods
 * 
 */
public class TestCall 
{

	WebDriver driver;
	Properties prop;
	String token;
	
	// classes reference variable
	ClickTatoc ct;
	Basic_Course basic;
	Greenbox gb;
	SwitchFrame sf;
	DragDrop dp;
	LaunchPopUp pp;
	Proceednext pn;
	CopyToken cp;
	Cookies c;
	@BeforeTest
	public void loadUrl() throws IOException 
	{
		prop = new Properties();

		File f = new File(System.getProperty("user.dir") + "/src/com/pageobjects/Locaters.properties");
		FileReader fr = new FileReader(f);
		prop.load(fr);
		
		
		  System.setProperty(prop.getProperty("DriverName"),prop.getProperty( "ChromeDriver"));
		  driver=new ChromeDriver();
		  
		  
		  driver.navigate().to(prop.getProperty("BaseUrl"));
		    
		 
	}
	
	
	
	
	
	@Test
	public void Step_01_Clicktatoc()
	{
			
		
		ct=new ClickTatoc(driver, prop);
		ct.clicktt();

		String actual="Welcome - T.A.T.O.C";
		Assert.assertEquals(actual,ct.getTatoc_title());
		
	}
	
	@Test
	public void Step_02_clickBasicCourse()
	{
		
		basic=new Basic_Course(driver,prop);
		basic.basicClick();
		Assert.assertEquals(prop.getProperty("BasicTitle"),basic.getTitle());
		
	}
	
	@Test
	public void Step_03_ClckGreenBox()
	{
		
		gb=new Greenbox(driver, prop);
		gb.clickGreen();
		String actual="Frame Dungeon - Basic Course - T.A.T.O.C";
		Assert.assertEquals(actual,driver.getTitle());
		
	}
	
	@Test
	public void Step_04_Frame()
	{
		
		
		sf=new SwitchFrame(driver, prop);
		sf.framecheck();
		
	}
	
	@Test
	public void Step_05_DrapDropBox()
	{
		dp=new DragDrop(driver, prop);
		dp.Drag();
		
	}
	
	@Test
	public void Step_06_Pop()
	{
		pp=new LaunchPopUp(driver, prop);
		pp.popup();
		
	}
	
	@Test 
	public void Step_07_proceed()
	{
		
		pn=new Proceednext(driver, prop);
		pn.Proceed();
		
	}
	
	@Test
	public void Step_08_Token()
	{
		cp=new CopyToken(driver, prop);
		 token=cp.Token();
		System.out.println(token);
	}
	
	@Test
	public void Step_09_CookieGen()
	{
		c=new Cookies(driver, prop);
		c.Cookie(token);
	}
	
	
	
	
	

}
