package com.QAjava;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class LongWord {

	public static void main(String[] args) throws Exception
	{
		
		  FileReader fr=new FileReader("/home/qainfotech/eclipse-workspace/Demo/test.txt"); Scanner sc=new
		  Scanner(fr);
		  
		  String l=""; String s="";
		  ArrayList al=new ArrayList<String>();
		  
		  while(sc.hasNext()) 
		  { 
			  s=sc.next();
		  
			  if(s.length()>l.length())
			  {
				  l=s;
				  al.add(s);
						  
			  }
			  else if(s.length()==l.length())
			  {
				  l=s;
				  al.add(s);
				  
			  }
		  }
		 
		  System.out.println("Longest word==>"+al);
		  
		
		
		  fr.close();
		  sc.close();
	}

	}

