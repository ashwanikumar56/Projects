package com.QAjava;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int r=0,s=0;
		if(a>1000)
		{
			System.out.println("Enter valid input");
		}
		else
		{
			while(a!=0)
			{
				r=a%10;
				s=s+r;
				a=a/10;
				
				
			}
			
			System.out.println(s);
		}
		
		sc.close();
	}

}
