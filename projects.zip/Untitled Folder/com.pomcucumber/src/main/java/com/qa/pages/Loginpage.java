package com.qa.pages;

public class Loginpage 
{
	
	

}
